# VARZZ Floating Panel

A small Android floating overlay demo with draggable header and Start/Stop/Close buttons.

This is a visual overlay only. It does not inject into games, modify game memory, automate aiming, change movement speed, load DLLs, or bypass anti-cheat systems.

Build with Gradle 8.11.1, JDK 17, Android Gradle Plugin 8.7.3, and Android SDK 35.
