package com.varzz.floatingpanel

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            background = GradientDrawable().apply {
                setColor(Color.rgb(28, 20, 42))
                cornerRadius = 24f
                setStroke(3, Color.rgb(160, 90, 255))
            }
        }

        val header = TextView(this).apply {
            text = "VARZZ  •  FLOATING"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(4, 2, 4, 12)
        }
        val status = TextView(this).apply {
            text = "Status: Siap"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(4, 4, 4, 10)
        }
        val start = Button(this).apply { text = "START" }
        val stop = Button(this).apply { text = "STOP" }
        val close = Button(this).apply { text = "TUTUP PANEL" }

        start.setOnClickListener { status.text = "Status: Aktif (overlay visual)" }
        stop.setOnClickListener { status.text = "Status: Berhenti" }
        close.setOnClickListener { stopSelf() }

        box.addView(header)
        box.addView(status)
        box.addView(start)
        box.addView(stop)
        box.addView(close)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = params.x
                        startY = params.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - downX).toInt()
                        params.y = startY + (event.rawY - downY).toInt()
                        windowManager.updateViewLayout(box, params)
                        return true
                    }
                }
                return false
            }
        })

        panel = box
        windowManager.addView(box, params)
    }

    override fun onDestroy() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
